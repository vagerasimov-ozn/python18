def somefunc():
    print('m1.somefunc')
