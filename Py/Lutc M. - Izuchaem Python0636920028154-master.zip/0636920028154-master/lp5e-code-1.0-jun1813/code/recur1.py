X = 1
import recur2                             # Run recur2 now if it doesn't exist
Y = 2
