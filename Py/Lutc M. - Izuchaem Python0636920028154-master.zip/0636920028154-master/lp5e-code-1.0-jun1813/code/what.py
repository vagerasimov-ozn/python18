#!python3
import sys
print(sys.version.split()[0])     # First part of string
