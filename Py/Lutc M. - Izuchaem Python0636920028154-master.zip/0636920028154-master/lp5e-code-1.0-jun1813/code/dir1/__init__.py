print('dir1 init')
x = 1
